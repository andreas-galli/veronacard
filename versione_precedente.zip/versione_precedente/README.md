veronacard/
├── 2017_timelines/                  # Contiene qualche timeline generata dell'anno 2017
├── 2018_timelines/                  # Contiene qualche timeline generata dell'anno 2018
├── first3mov/                       # Analisi dei primi 3 movimenti più comuni per ogni cluster presente
├── first4mov/                       # Analisi dei primi 4 movimenti più comuni per ogni cluster presente
├── results/                         # Cartella in cui sono contenuti i csv utili al clustering
├── clustering.py                    # Definizione della funzione che esegue il clustering (K-Means clustering)
├── distanceMatrix.py                # Generazione della matrice delle distanze, da adattare alla metrica utilizzata
├── firstNMovements.py               # Generazione di un csv contenente tutti i primi 3 spostamenti fatti da ogni id_vc
├── graph_similarity.py              # Contiene funzioni per il calcolo della similarità, diverse metriche disponibili
├── graph.py                         # Contiene funzioni per la creazione e visualizzazione grafica di uno o più grafi
├── log_veronaCard.csv               # Dataset di partenza, contenente le strisciate
├── main.py                          # Test di alcune funzionalità ed esecuzione del clustering
├── matrix.py                        # Contiene funzioni per la generazione di matrici, tra cui le distanceMatrix 
├── poi_info.csv                     # Contiene la lista dei POI e alcune informazioni su di essi
├── poi_timeline.py                  # Generazione di una timeline, i cui parametri sono da impostare
└── README.md                        # Questo file